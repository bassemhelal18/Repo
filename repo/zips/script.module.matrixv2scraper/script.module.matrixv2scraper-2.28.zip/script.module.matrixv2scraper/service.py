import xbmc
from resources.lib import tools


tools.repair()