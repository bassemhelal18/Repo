import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.matrix/?site=cViewing&function=delViewingMenu)", True)
