import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.matrix/?site=cFav&function=delBookmarkMenu)", True)
